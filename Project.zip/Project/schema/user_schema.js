
const Mongoose = require("mongoose");




//creating refrence userSchema to user collection
var Schema = Mongoose.Schema;
var userSchema = new Schema({
  _id:String,
  password:String,
  name:
  {firstname:String,
    middlename:String,
    lastname:String
  },
  contact:String,
  Address:[{
    user_id:{
      type:String,
     // ref:'User'
    },
    description:String,
    state:String,
    country:String,
    code:Number,
    _id:false
  }],
  userType:{
    type:String,
    enum:['buyer','seller','Developer'],
  },
  createdAt:Date,
  addToCart:[{
    user_id:{
      type:String,
    //  ref:'User'
    },
    product_id:{
      type:String,
      //ref:'Product'
    },
    addedAt:Date
  }]
});



//creating model for User,Product and Order using the schema we designed above
var UserModel=Mongoose.model('User',userSchema);

module.exports =UserModel;