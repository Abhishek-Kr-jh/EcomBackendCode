const express = require("express")
const app=express();

const mongoose = require("mongoose")
mongoose.connect("mongodb://localhost:27017/acmedb", { useNewUrlParser: true });

const routes1 = require("./routes/userApi")
const routes2 = require("./routes/productApi")
const routes3 = require("./routes/orderApi")
const bodyParser = require("body-parser") 

//const app = require("./routes/userApi")
// mongoose
//   .connect("mongodb://localhost:27017/acmedb", { useNewUrlParser: true })
//   .then(() => {
//     const app = express()
//     app.use(bodyParser.json()) // new
//     app.use("/user", routes1)
//     app.use("/product", routes2)
//     app.use("/api", routes3)

//     app.listen(5000, () => {
//       console.log("Server has started!")
//     })
//   })

const db=mongoose.connection;
db.on('error',(error)=>console.log(error));
db.once('open',()=>{
  console.log('connected to db');
  app.use('/product',routes2);
  app.use('/user',routes1);
 
})

app.listen(5000,()=>console.log('server started'));
  